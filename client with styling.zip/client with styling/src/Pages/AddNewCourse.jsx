import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const AddNewCourse = () => {
    const [courseCode, setCourseCode] = useState('');
    const [courseName, setCourseName] = useState('');
    const [assignedTeacher, setAssignedTeacher] = useState('');
    const [assignedClass, setAssignedClass] = useState('');
    const [teachers, setTeachers] = useState([]);
    const [students, setStudents] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        try {
            const teacherResponse = await fetch('/api/v1/users?role=teacher');
            const teacherData = await teacherResponse.json();
            setTeachers(teacherData.teachers);

            const studentResponse = await fetch('/api/v1/users?role=student');
            const studentData = await studentResponse.json();
            console.log(studentData);
            setStudents(studentData.teachers);
        } catch (error) {
            console.error('Error fetching users:', error);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const newCourse = {
            courseCode,
            courseName,
            assignedTeacher,
            assignedClass
        };

        try {
            const response = await fetch('/api/v1/addNewCourse', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newCourse)
            });

            const data = await response.json();

            if (data.error || !data){
                window.alert('Error while adding course');
                console.log(data.error);
            }
            else{
                window.alert('Successfully Added New Course');
                navigate('/manager/AllCourses');
            }

            setCourseCode('');
            setCourseName('');
            setAssignedTeacher('');
            setAssignedClass('');

        } catch (error) {
            console.error('Error adding new course:', error);
            window.alert('Error:', error);
        }
    };

    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container">
                    <a className="navbar-brand" href="/manager" style={{ fontWeight: "bold" }}>Manager Dashboard</a>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="http://localhost:3000/" style={{marginLeft: "850px", border:"2px solid #0d2e49", backgroundColor:"#2e91e8", color: "white"}}>Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div className="container mt-5">
                <h2 className="mb-4" style={{color: "white"}}>Add New Course</h2>
                <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                        <label htmlFor="courseCode" className="form-label" style={{color: "white"}}>Course Code:</label>
                        <input type="text" className="form-control" id="courseCode" value={courseCode} onChange={(e) => setCourseCode(e.target.value)} />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="courseName" className="form-label" style={{color: "white"}}>Course Name:</label>
                        <input type="text" className="form-control" id="courseName" value={courseName} onChange={(e) => setCourseName(e.target.value)} />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="assignedTeacher" className="form-label" style={{color: "white"}}>Assigned Teacher:</label>
                        <select className="form-select" id="assignedTeacher" value={assignedTeacher} onChange={(e) => setAssignedTeacher(e.target.value)}>
                            <option value="">Select Teacher</option>
                            {teachers.map((teacher) => (
                                <option key={teacher._id} value={teacher._id}>{teacher.fullname}</option>
                            ))}
                        </select>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="assignedClass" className="form-label" style={{color: "white"}}>Assigned Class:</label>
                        <select className="form-select" id="assignedClass" value={assignedClass} onChange={(e) => setAssignedClass(e.target.value)}>
                            <option value="">Select Class</option>
                            {students.map((student) => (
                                <option key={student._id} value={`${student.batchNo} - ${student.department}`}>{`${student.batchNo} - ${student.department}`}</option>
                            ))}
                        </select>
                    </div>
                    <button type="submit" className="btn btn-primary">Add Course</button>
                </form>
            </div>
        </div>
    );
};

export default AddNewCourse;
