import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

export function AllCourses() {
  const [courses, setCourses] = useState([]);
  const [teacherFullNames, setTeacherFullNames] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    fetchCourses();
  }, []);

  useEffect(() => {
    fetchTeacherFullNames();
  }, [courses]);

  const fetchCourses = async () => {
    try {
      const response = await fetch("/api/v1/courses");
      const data = await response.json();
      setCourses(data.courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
    }
  };

  const fetchTeacherFullNames = async () => {
    try {
      const teacherIds = courses.map((course) => course.assignedTeacher);
      const requests = teacherIds.map((teacherId) =>
        fetch(`/api/v1/users/${teacherId}`)
          .then((response) => response.json())
          .then((data) => ({ [teacherId]: data.teacherFullName }))
      );
      const responses = await Promise.all(requests);
      const fullNameMap = responses.reduce(
        (acc, response) => ({ ...acc, ...response }),
        {}
      );
      setTeacherFullNames(fullNameMap);
    } catch (error) {
      console.error("Error fetching teacher full names:", error);
    }
  };

  const handleEditCourse = (courseId) => {
    navigate(`/manager/editCourse/${courseId}`);
    console.log("Editing course with id:", courseId);
  };

  const handleDeleteCourse = (courseId) => {
    // Logic to handle deleting the course with courseId
    console.log("Deleting course with id:", courseId);
  };

  const handleAddCourse = () => {
    navigate("/manager/addNewCourse");
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container">
          <a className="navbar-brand" href="/manager"style={{ fontWeight: "bold" }}>
            Manager Dashboard
          </a>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item">
                <a className="nav-link" href="http://localhost:3000/" style={{marginLeft: "850px", border:"2px solid #0d2e49", backgroundColor:"#2e91e8", color: "white"}}>
                  Logout
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <div className="container mt-5">
        <button className="btn btn-primary mb-3" onClick={handleAddCourse}>
          Add New Course
        </button>
        <table className="table">
          <thead>
            <tr>
              <th style={{ background: "#0d2e49", color: "white", padding: "10px", border: "2px solid white" }} scope="col">Course Code</th>
              <th style={{ background: "#0d2e49", color: "white", padding: "10px", border: "2px solid white" }} scope="col">Course Name</th>
              <th style={{ background: "#0d2e49", color: "white", padding: "10px", border: "2px solid white" }} scope="col">Assigned Teacher</th>
              <th style={{ background: "#0d2e49", color: "white", padding: "10px", border: "2px solid white" }} scope="col">Assigned Class</th>
              <th style={{ background: "#0d2e49", color: "white", padding: "10px", border: "2px solid white" }} scope="col">Actions</th>
            </tr>
          </thead>
          <tbody>
            {courses.map((course) => (
              <tr key={course._id}>
                <td style={{ border: "2px solid #0d2e49", padding: "8px" }} >{course.courseCode}</td>
                <td style={{ border: "2px solid #0d2e49", padding: "8px" }} >{course.courseName}</td>
                <td style={{ border: "2px solid #0d2e49", padding: "8px" }} >{course.assignedTeacher.fullname || "Loading..."}</td>
                <td style={{ border: "2px solid #0d2e49", padding: "8px" }} >{course.assignedClass}</td>
                <td style={{ border: "2px solid #0d2e49", padding: "8px" }} >
                  <button
                    className="btn btn-sm btn-primary me-1"
                    onClick={() => handleEditCourse(course._id)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={() => handleDeleteCourse(course._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AllCourses;
