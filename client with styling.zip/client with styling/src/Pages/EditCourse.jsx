import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const EditCourse = () => {
    const { courseId } = useParams();
    const [courseCode, setCourseCode] = useState('');
    const [courseName, setCourseName] = useState('');
    const [assignedTeacher, setAssignedTeacher] = useState('');
    const [assignedClass, setAssignedClass] = useState('');
    const [teachers, setTeachers] = useState([]);
    const [classes, setClasses] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        fetchCourseDetails();
        fetchUsers();
    }, []);

    const fetchCourseDetails = async () => {
        try {
            const response = await fetch(`/api/v1/courses/${courseId}`);
            const data = await response.json();
            const { courseCode, courseName, assignedTeacher, assignedClass } = data.course;
            setCourseCode(courseCode);
            setCourseName(courseName);
            setAssignedTeacher(assignedTeacher);
            setAssignedClass(assignedClass);
        } catch (error) {
            console.error('Error fetching course details:', error);
        }
    };

    const fetchUsers = async () => {
        try {
            const teacherResponse = await fetch('/api/v1/users?role=teacher');
            const teacherData = await teacherResponse.json();
            setTeachers(teacherData.teachers);

            const classResponse = await fetch('/api/v1/users?role=student');
            const classData = await classResponse.json();
            setClasses(classData.teachers);
        } catch (error) {
            console.error('Error fetching users:', error);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const updatedCourse = {
            courseCode,
            courseName,
            assignedTeacher,
            assignedClass
        };

        try {
            const response = await fetch(`/api/v1/updateCourse/${courseId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(updatedCourse)
            });

            const data = await response.json();

            if(data.error || !data){
                window.alert('Error while adding course');
                console.log(data.error);
            }
            else{
                window.alert('Successfully Updated Course');
                navigate('/manager/AllCourses');
            }

            navigate('/manager/allCourses');
        } catch (error) {
            console.error('Error updating course:', error);
        }
    };

    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container">
                    <a className="navbar-brand" href="/manager" style={{ fontWeight: "bold" }}>Manager Dashboard</a>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="http://localhost:3000/" style={{marginLeft: "850px", border:"2px solid #0d2e49", backgroundColor:"#2e91e8", color: "white"}} >Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div className="container mt-5">
                <h2 className="mb-4" style={{color: "white"}}>Edit Course</h2>
                <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                        <label htmlFor="courseCode" className="form-label" style={{color: "white"}}>Course Code:</label>
                        <input type="text" className="form-control" id="courseCode" value={courseCode} onChange={(e) => setCourseCode(e.target.value)} />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="courseName" className="form-label" style={{color: "white"}}>Course Name:</label>
                        <input type="text" className="form-control" id="courseName" value={courseName} onChange={(e) => setCourseName(e.target.value)} />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="assignedTeacher" className="form-label" style={{color: "white"}}>Assigned Teacher:</label>
                        <select className="form-select" id="assignedTeacher" value={assignedTeacher} onChange={(e) => setAssignedTeacher(e.target.value)}>
                            <option value="">Select Teacher</option>
                            {teachers.map((teacher) => (
                                <option key={teacher._id} value={teacher._id}>{teacher.fullname}</option>
                            ))}
                        </select>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="assignedClass" className="form-label" style={{color: "white"}}>Assigned Class:</label>
                        <select className="form-select" id="assignedClass" value={assignedClass} onChange={(e) => setAssignedClass(e.target.value)}>
                            <option value="">Select Class</option>
                            {classes.map((classItem) => (
                                <option key={classItem._id} value={`${classItem.batchNo} - ${classItem.department}`}>{`${classItem.batchNo} - ${classItem.department}`}</option>
                            ))}
                        </select>
                    </div>
                    <button type="submit" className="btn btn-primary">Update Course</button>
                </form>
            </div>
        </div>
    );
};

export default EditCourse;
