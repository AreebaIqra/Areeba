import React, { useState } from "react";
import {Link, useNavigate } from "react-router-dom";
import Cookies from 'js-cookie';

export function Home() {
    const navigate = useNavigate();
    const [userType, setUserType] = useState("");
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [isLoading, setIsLoading] = useState(false);

    const handleLogin = async () => {
        setIsLoading(true);
        console.log(username);
        const response = await fetch("/api/v1/signin", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                role: userType,
                registration: username,
                password: password,
            })
        });
        const data = await response.json();
        console.log(data);
        if(data.error || !data){
            window.alert(data.error);
        }
        else{
            Cookies.set('userId', data.user);
            if(userType==='manager'){
                navigate('/manager');
            }
            else if(userType==='student'){
                navigate('/student');
            }
            else if(userType==='teacher'){
                navigate('/teacher');
            }
            // alert("LoggedIn");
        }
        setIsLoading(false);
    };

    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container">
                    <a className="navbar-brand" style={{ fontWeight: "bold", fontSize: "20px" }} href="#">Smart Attendance Management System </a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <a className="nav-link" style={{marginLeft: "90px"}} href="#">Student Attendance</a>
                            </li>
                        </ul>
                        <div className="text-end">
                            <a href="/signup" className="btn btn-primary me-2">Registration</a>
                        </div>
                    </div>
                </div>
            </nav>

            <div className="container mt-5" style={{width: "80%", height: "200%"}}>
                <div className="row justify-content-center" style={{ borderCollapse: "collapse", width: "100%",marginTop: "100px" }}>
                    <div className="col-md-6">
                        <div className="card"style={{ border: "2px solid #082e49"}}>
                            <div className="card-body">
                                <h5 className="card-title text-center">Login</h5>
                                <form>
                                <div className="mb-3" style={{ fontWeight: "bold", fontSize: "15px" }}>
                                        <label htmlFor="userType">Login As</label>
                                        <select
                                            id="userType"
                                            className="form-select"
                                            onChange={(e) => setUserType(e.target.value)}
                                        >
                                            <option value="">Select User Type</option>
                                            <option value="student">Student</option>
                                            <option value="teacher">Teacher</option>
                                            <option value="manager">Manager</option>
                                        </select>
                                    </div>
                                    {userType === "student" && (
                                        <div className="mb-3" style={{ fontWeight: "bold" }}>
                                            <label htmlFor="regNo">Registration No:</label>
                                            <input
                                                type="text"
                                                id="regNo"
                                                className="form-control"
                                                placeholder="Enter Registration No"
                                                value={username}
                                                onChange={(e) => setUsername(e.target.value)}
                                            />
                                        </div>
                                    )}
                                    {userType === "teacher" && (
                                        <div className="mb-3" style={{ fontWeight: "bold" }}>
                                            <label htmlFor="email">Email:</label>
                                            <input
                                                type="email"
                                                id="email"
                                                className="form-control"
                                                placeholder="Enter Email"
                                                value={username}
                                                onChange={(e) => setUsername(e.target.value)}
                                            />
                                        </div>
                                    )}
                                    {userType === "manager" && (
                                        <div className="mb-3" style={{ fontWeight: "bold" }}>
                                            <label htmlFor="email">Username:</label>
                                            <input
                                                type="text"
                                                id="text"
                                                className="form-control"
                                                placeholder="Enter Username"
                                                value={username}
                                                onChange={(e) => setUsername(e.target.value)}
                                            />
                                        </div>
                                    )}
                                    <div className="mb-3" style={{ fontWeight: "bold" }}>
                                        <label htmlFor="password">Password</label>
                                        <input
                                            type="password"
                                            id="password"
                                            className="form-control"
                                            placeholder="Enter Password"
                                            value={password}
                                            onChange={(e) => setPassword(e.target.value)}
                                        />
                                    </div>
                                    <div style={{ textAlign: "center" }}> 
                                    <button 
                                        type="button"  
                                        className="btn btn-primary btn-block"
                                        onClick={handleLogin}
                                    >
                                        Login 
                                    </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Home;
