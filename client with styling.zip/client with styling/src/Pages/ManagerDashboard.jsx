import React from 'react';

export function ManagerDashboard() {
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container">
                    <a className="navbar-brand" href="#" style={{ fontWeight: "bold" }}>Manager Dashboard</a>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="http://localhost:3000/" style={{marginLeft: "850px", border:"2px solid #0d2e49", backgroundColor:"#2e91e8", color: "white"}}>Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div className="container mt-5">
                <div className="row">
                    <div className="col-md-4">
                        <a href="/manager/AllCourses" className="text-decoration-none">
                            <div className="card bg-primary text-white mb-3">
                                <div className="card-body">
                                    <h5 className="card-title">View Courses</h5>
                                    <p className="card-text">View all available courses.</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div className="col-md-4">
                        <a href="/manager/TeacherDetails" className="text-decoration-none">
                            <div className="card bg-info text-white mb-3">
                                <div className="card-body">
                                    <h5 className="card-title">View Teachers</h5>
                                    <p className="card-text">View all registered teachers.</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div className="col-md-4">
                        <a href="/manager/StudentDetails" className="text-decoration-none">
                            <div className="card bg-success text-white mb-3">
                                <div className="card-body">
                                    <h5 className="card-title">View Students</h5>
                                    <p className="card-text">View all registered students.</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div className="col-md-4">
                        <a href="/manager/ScheduleClasses" className="text-decoration-none">
                            <div className="card bg-danger text-white mb-3">
                                <div className="card-body">
                                    <h5 className="card-title">Schedule Classes</h5>
                                    <p className="card-text">Schedule classes for students.</p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ManagerDashboard;
