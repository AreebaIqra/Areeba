import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export function Registration() {
  const navigate = useNavigate();
  const [userType, setUserType] = useState("");
  const [registrationNo, setRegistrationNo] = useState("");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [batchNo, setBatchNo] = useState("");
  const [department, setDepartment] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [profilePicture, setProfilePicture] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleRegister = async () => {
    setIsLoading(true);
    const formData = new FormData();
    formData.append("role", userType);
    formData.append("fullname", fullName);
    formData.append("email", email);
    formData.append(
      "registration",
      userType === "student" ? registrationNo : "0"
    );
    formData.append("batchNo", userType === "student" ? batchNo : "0");
    formData.append("department", department);
    formData.append("password", password);
    formData.append("confirmPassword", confirmPassword);
    formData.append("profilePicture", profilePicture);
    console.log("FormData content:");
    for (const pair of formData.entries()) {
      console.log(pair[0] + ": " + pair[1]);
    }
    const response = await fetch("/api/v1/register", {
      method: "POST",
      body: formData,
    });
    const data = await response.json();

    if (data.error || !data) {
      window.alert(data.error);
    } else {
      // window.alert("Successfully Registered");
      navigate("/");
    }
    setIsLoading(false);
  };

  const handleProfilePictureChange = (e) => {
    setProfilePicture(e.target.files[0]);
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container">
          <a className="navbar-brand" style={{ fontWeight: "bold", fontSize: "20px" }} href="#">
            Smart Attendance Management System
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <a className="nav-link"  style={{marginLeft: "90px"}} href="#">
                  Student Attendance
                </a>
              </li>
            </ul>
            <div className="text-end">
              <a href="/" className="btn btn-primary me-2">
                Login
              </a>
            </div>
          </div>
        </div>
      </nav>
      <div className="container my-5" style={{width: "80%", height: "200%"}}>
        <div className="row justify-content-center" style={{ borderCollapse: "collapse", width: "100%",marginTop: "100px" }}>
          <div className="col-md-6">
            <div className="card" style={{ border: "2px solid #082e49"}}>
              <div className="card-body">
                <h5 className="card-title text-center">Registration</h5>
                <form>
                  <div className="mb-3"style={{ fontWeight: "bold" }}>
                    <label htmlFor="userType">Register As:</label>
                    <select
                      id="userType"
                      className="form-select"
                      onChange={(e) => setUserType(e.target.value)}
                    >
                      <option value="">Select User Type</option>
                      <option value="student">Student</option>
                      <option value="teacher">Teacher</option>
                    </select>
                  </div>
                  {userType === "student" && (
                    <>
                      <div className="mb-3" style={{ fontWeight: "bold" }}>
                        <label htmlFor="profilePicture">Profile Picture:</label>
                        <input
                          type="file"
                          id="profile"
                          className="form-control"
                          onChange={handleProfilePictureChange}
                          required
                        />
                      </div>
                      <div className="mb-3" style={{ fontWeight: "bold" }}>
                        <label htmlFor="registrationNo">Registration No:</label>
                        <input
                          type="text"
                          id="registrationNo"
                          className="form-control"
                          placeholder="FA20-BSE-149"
                          value={registrationNo}
                          onChange={(e) => setRegistrationNo(e.target.value)}
                          required
                        />
                      </div>
                      <div className="mb-3" style={{ fontWeight: "bold" }}>
                        <label htmlFor="fullName">Full Name:</label>
                        <input
                          type="text"
                          id="fullName"
                          className="form-control"
                          placeholder="Enter Full Name"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          required
                        />
                      </div>
                      <div className="mb-3" style={{ fontWeight: "bold" }}>
                        <label htmlFor="email">Email:</label>
                        <input
                          type="email"
                          id="email"
                          className="form-control"
                          placeholder="Enter Email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                        />
                      </div>
                      <div className="mb-3" style={{ fontWeight: "bold" }}>
                        <label htmlFor="batchNo">Batch No:</label>
                        <input
                          type="text"
                          id="batchNo"
                          className="form-control"
                          placeholder="FA20"
                          value={batchNo}
                          onChange={(e) => setBatchNo(e.target.value)}
                          required
                        />
                      </div>
                      <div className="mb-3" style={{ fontWeight: "bold" }}>
                        <label htmlFor="department">Department:</label>
                        <input
                          type="text"
                          id="department"
                          className="form-control"
                          placeholder="BCS"
                          value={department}
                          onChange={(e) => setDepartment(e.target.value)}
                          required
                        />
                      </div>
                    </>
                  )}
                  {userType === "teacher" && (
                    <>
                      <div className="mb-3" style={{ fontWeight: "bold" }}>
                        <label htmlFor="fullName">Full Name:</label>
                        <input
                          type="text"
                          id="fullName"
                          className="form-control"
                          placeholder="Enter Full Name"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          required
                        />
                      </div>
                      <div className="mb-3" style={{ fontWeight: "bold" }}>
                        <label htmlFor="email">Email:</label>
                        <input
                          type="email"
                          id="email"
                          className="form-control"
                          placeholder="Enter Email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                        />
                      </div>
                      <div className="mb-3" style={{ fontWeight: "bold" }}>
                        <label htmlFor="department">Department:</label>
                        <input
                          type="text"
                          id="department"
                          className="form-control"
                          placeholder="Enter Department"
                          value={department}
                          onChange={(e) => setDepartment(e.target.value)}
                          required
                        />
                      </div>
                    </>
                  )}
                  <div className="mb-3" style={{ fontWeight: "bold" }}>
                    <label htmlFor="password">Password:</label>
                    <input
                      type="password"
                      id="password"
                      className="form-control"
                      placeholder="Enter Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                  <div className="mb-3" style={{ fontWeight: "bold" }}>
                    <label htmlFor="confirmPassword">Confirm Password:</label>
                    <input
                      type="password"
                      id="confirmPassword"
                      className="form-control"
                      placeholder="Confirm Password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                    />
                  </div>
                </form>
                <button
                  type="button"
                  className="btn btn-primary btn-block"
                  onClick={handleRegister}
                  disabled={isLoading}
                >
                  {isLoading ? "Registering..." : "Register"}
                </button>
                {isLoading && (
                  <div className="text-center mt-3">
                    <div className="spinner-border" role="status">
                      <span className="visually-hidden">Loading...</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Registration;
