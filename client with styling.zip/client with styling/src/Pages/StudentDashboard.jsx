import React, { useState, useEffect } from "react";
import {
  Navbar,
  Nav,
  Button,
  Table,
  ProgressBar,
  Modal,
} from "react-bootstrap";
import { useCookies } from "react-cookie";
import { Link, useNavigate } from "react-router-dom";
import Cookies from "universal-cookie";

const StudentDashboard = () => {
  const [registeredCourses, setRegisteredCourses] = useState([]);
  const [courses, setCourses] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [cookies] = useCookies(["userId"]);
  const userId = cookies.userId;
  const navigate = useNavigate();

  useEffect(() => {
    fetchRegisteredCourses();
    fetchCourses();
  }, []);

  const fetchRegisteredCourses = async () => {
    try {
      const response = await fetch(
        `/api/v1/student/${userId}/registered-courses`
      );
      const data = await response.json();
      setRegisteredCourses(data.registeredCourses);
      console.log(data.registeredCourses);
    } catch (error) {
      console.error("Error fetching registered courses:", error);
    }
  };

  const fetchCourses = async () => {
    try {
      const response = await fetch("/api/v1/courses");
      const data = await response.json();
      setCourses(data.courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
    }
  };

  const handleLogout = () => {
    const cookies = new Cookies();
    cookies.remove("userId");
    navigate("/");
  };

  const handleRegisterCourse = () => {
    setModalOpen(true);
  };

  const handleModalClose = () => {
    setModalOpen(false);
  };

  const handleCourseSelect = async (course) => {
    try {
      const response = await fetch("/api/v1/student/register-course", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ course: course._id, user: userId }),
      });
      const data = await response.json();
      if (!data.error || data) {
        console.log("Course registered successfully");
        fetchRegisteredCourses();
      } else {
        console.error("Failed to register course");
        window.alert("Failed to register due to some error.");
      }
    } catch (error) {
      console.error("Error registering course:", error);
    }
  };

  const handleCourseRegister = async () => {
    console.log("Registering course:", selectedCourse);
    setModalOpen(false);
  };

  return (
    <div>
      <Navbar bg="light" expand="lg">
        <Navbar.Brand style={{ fontWeight: "bold" }}>Student Dashboard </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
            <Nav.Link onClick={handleLogout} style={{marginLeft: "950px", border:"2px solid #0d2e49", backgroundColor:"#2e91e8", color: "white"}}>Logout</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
      <h2 style={{ color: '#FFFFFF' }}>Registered Courses</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th >Course Code</th>
            <th>Course Name</th>
            <th>Teacher Name</th>
            <th>Attendance</th>
          </tr>
        </thead>
        <tbody>
          {registeredCourses.length === 0 ? (
            <tr>
              <td colSpan="4">No registered courses</td>
            </tr>
          ) : (
            registeredCourses.map((course) => (
              <tr key={course.course._id}>
                <td>{course.course.courseCode}</td>
                <td>{course.course.courseName}</td>
                <td>{course.course.assignedTeacher.fullname}</td>
                <td>
                  <ProgressBar
                    now={course.attendance}
                    label={`${course.attendance}%`}
                  />
                </td>
              </tr>
            ))
          )}
        </tbody>
      </Table>

      <Button onClick={handleRegisterCourse}>Register Course</Button>

      <Modal
        show={modalOpen}
        onHide={handleModalClose}
        dialogClassName="modal-90w"
      >
        <Modal.Header closeButton>
          <Modal.Title>Register Course</Modal.Title>
        </Modal.Header>
        <Modal.Body
          style={{ maxHeight: "calc(100vh - 200px)", overflowY: "auto" }}
        >
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Course Code</th>
                <th>Course Name</th>
                <th>Teacher Name</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {courses.map((course) => (
                <tr key={course._id}>
                  <td>{course.courseCode}</td>
                  <td>{course.courseName}</td>
                  <td>{course.assignedTeacher.fullname}</td>
                  <td>
                    <Button onClick={() => handleCourseSelect(course)}>
                      Register
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={handleModalClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default StudentDashboard;
