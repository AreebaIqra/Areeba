import React, { useState, useEffect } from 'react';

const StudentDetails = () => {
    const [students, setStudents] = useState([]);

    useEffect(() => {
        fetchTeachers();
    }, []);

    const fetchTeachers = async () => {
        try {
            const response = await fetch('/api/v1/users?role=student');
            const data = await response.json();
            setStudents(data.teachers);
        } catch (error) {
            console.error('Error fetching teachers:', error);
        }
    };

    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container">
                    <a className="navbar-brand" href="/manager" style={{ fontWeight: "bold" }}>Manager Dashboard</a>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="http://localhost:3000/" style={{marginLeft: "850px", border:"2px solid #0d2e49", backgroundColor:"#2e91e8", color: "white"}}>Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        <div className='container my-5'>
            <h2 style={{color: "white"}} >Student Details</h2>
            <table className="table">
                <thead>
                    <tr>
                        <th style={{ background: "#0d2e49", color: "white", padding: "10px", border: "2px solid white" }}>Full Name</th>
                        <th style={{ background: "#0d2e49", color: "white", padding: "10px", border: "2px solid white" }}>Email</th>
                        <th style={{ background: "#0d2e49", color: "white", padding: "10px", border: "2px solid white" }}>Deparment</th>
                        <th style={{ background: "#0d2e49", color: "white", padding: "10px", border: "2px solid white" }}>BatchNo</th>
                        <th style={{ background: "#0d2e49", color: "white", padding: "10px", border: "2px solid white" }}>Registration No</th>
                    </tr>
                </thead>
                <tbody>
                    {students.map((student) => (
                        <tr key={student._id}>
                            <td style={{ border: "2px solid #0d2e49", padding: "8px" }}>{student.fullname}</td>
                            <td style={{ border: "2px solid #0d2e49", padding: "8px" }}>{student.email}</td>
                            <td style={{ border: "2px solid #0d2e49", padding: "8px" }}>{student.department}</td>
                            <td style={{ border: "2px solid #0d2e49", padding: "8px" }}>{student.batchNo}</td>
                            <td style={{ border: "2px solid #0d2e49", padding: "8px" }}>{student.registrationNo}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
        </div>
    );
};

export default StudentDetails;
