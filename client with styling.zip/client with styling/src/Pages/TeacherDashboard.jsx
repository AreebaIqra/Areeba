import React, { useState, useEffect } from "react";
import {
  Navbar,
  Nav,
  Table,
  Modal,
  Button,
  Form,
  ProgressBar,
} from "react-bootstrap";
import { useCookies } from "react-cookie";
import { useNavigate } from "react-router-dom";
import Cookies from "universal-cookie";

const TeacherDashboard = () => {
  const [assignedCourses, setAssignedCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [showAttendanceModal, setShowAttendanceModal] = useState(false);
  const [studentAttendance, setStudentAttendance] = useState([]);
  const [showTimetableModal, setShowTimetableModal] = useState(false);
  const [scheduleData, setScheduleData] = useState([]);
  const [availableSlotTimes, setAvailableSlotTimes] = useState([]);
  const [availableDays, setAvailableDays] = useState([]);
  const [cookies] = useCookies(["userId"]);
  const userId = cookies.userId;
  const navigate = useNavigate();

  useEffect(() => {
    fetchAssignedCourses();
    fetchTimetableData();
  }, []);

  const fetchTimetableData = async () => {
    try {
      const response = await fetch(`/api/v1/teacher/${userId}/timetable`);
      const data = await response.json();
      setScheduleData(data.schedule);

      const uniqueDays = [
        ...new Set(data.schedule.map((schedule) => schedule.day)),
      ];
      const uniqueSlotTimes = [
        ...new Set(data.schedule.map((schedule) => schedule.slot)),
      ];

      setAvailableDays(uniqueDays);
      setAvailableSlotTimes(uniqueSlotTimes);
    } catch (error) {
      console.error("Error fetching timetable:", error);
    }
  };
  const fetchAssignedCourses = async () => {
    try {
      const response = await fetch(
        `/api/v1/teacher/${userId}/assigned-courses`
      );
      const data = await response.json();
      setAssignedCourses(data.assignedCourses);
    } catch (error) {
      console.error("Error fetching assigned courses:", error);
    }
  };

  const handleLogout = () => {
    const cookies = new Cookies();
    cookies.remove("userId");
    navigate("/");
  };

  const handleUpdateAttendance = (course) => {
    setSelectedCourse(course);
    fetchStudentAttendance(course._id);
    setShowAttendanceModal(true);
  };

  const fetchStudentAttendance = async (courseId) => {
    try {
      const response = await fetch(`/api/v1/course/${courseId}/students`);
      const data = await response.json();
      console.log(data);
      setStudentAttendance(data.students);
    } catch (error) {
      console.error("Error fetching student attendance:", error);
    }
  };

  const handleCheckboxChange = (e, studentId, status) => {
    const { checked } = e.target;
    setStudentAttendance((prevState) =>
      prevState.map((student) =>
        student._id === studentId
          ? {
              ...student,
              present: status === 1 ? (checked ? 1 : 0) : checked ? 0 : 1,
            }
          : student
      )
    );
  };

  const handleCloseAttendanceModal = () => {
    setShowAttendanceModal(false);
    setSelectedCourse(null);
    setStudentAttendance([]);
  };

  const handleSaveAttendance = async () => {
    try {
      console.log(studentAttendance);
      const attendanceData = studentAttendance.map((student) => ({
        studentId: student._id,
        present: student.present,
      }));

      const response = await fetch(
        `/api/v1/course/${selectedCourse._id}/attendance`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            lectureNo: parseInt(document.getElementById("formLectureNo").value),
            slotTime: document.getElementById("formSlotTime").value,
            weekday: document.getElementById("formWeekday").value,
            attendance: attendanceData,
          }),
        }
      );

      const data = await response.json();
      if (!data.error || data) {
        console.log(data.message);
        handleCloseAttendanceModal();
      } else {
        window.alert("Failed to save student attendance");
        console.error("Failed to save student attendance");
      }
    } catch (error) {
      console.error("Error saving student attendance:", error);
    }
  };

  const handleViewTimetable = async () => {
    try {
      const response = await fetch(`/api/v1/teacher/${userId}/timetable`);
      const data = await response.json();
      setScheduleData(data.schedule);
      setShowTimetableModal(true);
    } catch (error) {
      console.error("Error fetching timetable:", error);
    }
  };

  const handleCloseTimetableModal = () => {
    setShowTimetableModal(false);
  };

  return (
    <div>
      <Navbar bg="light" expand="lg">
        <Navbar.Brand style={{ fontWeight: "bold", marginLeft:"10px" }}>Teacher Dashboard</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
          <Nav.Link onClick={handleViewTimetable} style={{marginLeft: "750px", border:"2px solid #0d2e49", backgroundColor:"#2e91e8", color: "white"}}>View Timetable</Nav.Link>
            <Nav.Link onClick={handleLogout} style={{marginLeft: "60px", border:"2px solid #0d2e49", backgroundColor:"#2e91e8", color: "white"}}>Logout</Nav.Link>
            {/* <Nav.Link onClick={handleViewTimetable} style={{marginLeft: "650px", border:"2px solid #0d2e49", backgroundColor:"#2e91e8", color: "white"}}>View Timetable</Nav.Link> */}
          </Nav>
        </Navbar.Collapse>
      </Navbar>

      <div className="container my-5">
        <h2 style={{ color: '#FFFFFF' }}>Assigned Courses</h2>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>Course Code</th>
              <th>Course Name</th>
              <th>Class</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {assignedCourses.length === 0 ? (
              <tr>
                <td colSpan="4">No registered courses</td>
              </tr>
            ) : (
              assignedCourses.map((course) => (
                <tr key={course._id}>
                  <td>{course.courseCode}</td>
                  <td>{course.courseName}</td>
                  <td>{course.assignedClass}</td>
                  <td>
                    <Button onClick={() => handleUpdateAttendance(course)}>
                      Update Attendance
                    </Button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </Table>
      </div>

      <Modal show={showAttendanceModal} onHide={handleCloseAttendanceModal}>
        <Modal.Header closeButton>
          <Modal.Title>Update Attendance</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Group controlId="formLectureNo">
            <Form.Label>Lecture No. </Form.Label>
            <Form.Control
              type="number"
              placeholder="Enter Lecture Number (greater than previous one)"
            />
          </Form.Group>
          <Form.Group controlId="formSlotTime">
            <Form.Label>Slot Time</Form.Label>
            <Form.Control as="select">
              {availableSlotTimes.map((slotTime) => (
                <option key={slotTime}>{slotTime}</option>
              ))}
            </Form.Control>
          </Form.Group>
          <Form.Group controlId="formWeekday">
            <Form.Label>Weekday</Form.Label>
            <Form.Control as="select">
              {availableDays.map((day) => (
                <option key={day}>{day}</option>
              ))}
            </Form.Control>
          </Form.Group>
          <Table striped bordered hover className="mt-3">
            <thead>
              <tr>
                <th>Student Name</th>
                <th>Status</th>
                <th>Attendance</th>
              </tr>
            </thead>
            <tbody>
              {studentAttendance.map((student) => (
                <tr key={student._id}>
                  <td>{student.name}</td>
                  <td>
                    <Form.Check
                      type="checkbox"
                      label="Present"
                      checked={student.present === 1}
                      onChange={(e) => handleCheckboxChange(e, student._id, 1)}
                    />
                    <Form.Check
                      type="checkbox"
                      label="Absent"
                      checked={student.present === 0}
                      onChange={(e) => handleCheckboxChange(e, student._id, 0)}
                    />
                  </td>

                  <td>
                    <ProgressBar
                      now={student.attendance}
                      label={`${student.attendance}%`}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseAttendanceModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleSaveAttendance}>
            Save Attendance
          </Button>
        </Modal.Footer>
      </Modal>

      <Modal show={showTimetableModal} onHide={handleCloseTimetableModal}>
        <Modal.Header closeButton>
          <Modal.Title>Timetable</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Day</th>
                <th>Time</th>
                <th>Course Code</th>
                <th>Course Name</th>
              </tr>
            </thead>
            <tbody>
              {scheduleData.map((schedule) => (
                <tr key={schedule._id}>
                  <td>{schedule.day}</td>
                  <td>{schedule.slot}</td>
                  <td>{schedule.courseCode}</td>
                  <td>{schedule.courseName}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseTimetableModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default TeacherDashboard;
